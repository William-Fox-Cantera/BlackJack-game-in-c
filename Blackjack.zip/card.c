/* Define all card/deck related functions as follows:
 * make_deck: generates a new list of 52 unique cards with ranks 1-13 and suits CDHS. Returns a pointer to the head of the list.
 *            Note: you must use malloc to create all 52 cards.
 * destroy_deck: consumes a pointer to a card. Free memory for all cards in the list.
 * shuffle: consumes a pointer to a card (expected to be the head of a list of cards). Returns a pointer to a card (the possibly new head).
 *          Randomly re-orders the cards in the list. Note; this function has been provided for you.
 * deal: consumes a pointer to a card (expected to be the head of a list of cards). Finds the last card in the list, prints its values, removes it
 *       from the list, and returns it (pointer to card).
 * total: consumes a pointer to card. Returns the sum of the values in the list headed by the given card (note: 10,11,12, and 13 all value as 10).
 * show: consumes a pointer to card. Prints the rank and suit of all cards in the list (this may be one card) on one line. For example:
 *       11H 9S 3D 1C 1S
*/
#include "card.h"
#include <stdio.h>
#include <stdlib.h>

card *make_deck() {
        //Length is 52 but starts at 0 so technically 53 which also accounts for the null character.
        int deckLen = 52;
        int deckIndex, rankIndex, currentSuit = 0;
        char suits[4] = {'C', 'D', 'H', 'S'};

        //HEAD OF DECK
        card *firstCard = malloc(sizeof(card));
        firstCard->rank = 1;
        firstCard->suit = suits[0];

        //NEXT CARD
        card *previousCard = malloc(sizeof(card));
        previousCard = firstCard;

        for(deckIndex = 1, rankIndex = 2; deckIndex < deckLen; deckIndex++, rankIndex++) {
                card *newCard = malloc(sizeof(card));
                newCard->rank = rankIndex;
                newCard->suit = suits[currentSuit];
                newCard->next = NULL;

                //ADDS POINTER TO NEXT CARD
                previousCard->next = newCard;
                //MAKES NEW CARDS
                previousCard = newCard;
                if(rankIndex == 13) {
                        rankIndex = 0;
                        currentSuit++;
                             }
        }
        return firstCard;
}

//Simple for loop to free memory used in making a deck of cards.
void destroy_deck(card *deck) {
        card *toBeDestroyed;
        toBeDestroyed = deck;

        //MAKE REFERENCE TO NEXT CARD, DESTROY PREVIOUS CARD
        while(toBeDestroyed->next != NULL) {
                toBeDestroyed = toBeDestroyed->next;
                free(toBeDestroyed);
                deck = toBeDestroyed;
        }
}

card *deal(card *deck) {
        card *Last;

        while(1) {
                deck = deck->next;
                if(deck->next->next == NULL) {
                        Last = deck->next;
                        deck->next = NULL;
                        break;
                }
        }

        //printf("Rank: %d Suit: %c\n", Last->rank, Last->suit);
        return Last;
}

int total(card *deck) {
        int total = 0;
        card *temp;
        temp = deck;

        while(temp != NULL) {
                if(temp->rank >= 11 && temp->rank <= 13) {
                        total += 10;
                }
                else {
                        total += temp->rank;
                }
                temp = temp->next;
        }
        return total;
}

void show(card *deck) {
        printf("Your Card is:\n%d%c\n\n", deck->rank, deck->suit);

}

/* counts the number of cards in the list headed by "deck" */
int count_deck(card *deck) {
    int count=0;
    /* No initialization required. When "deck" is NULL (zero), it's at the end. Otherwise, move to the
    next card and increment the count. No body of the for loop! */
    for(;deck;deck=deck->next,count++);
    return count;
}

/* Emulates a "riffle shuffle" of "deck". */
card *shuffle(card *deck) {
    int size = count_deck(deck);
    card *cut=deck;
    for(int i=0; i<size/2; i++){
        cut=cut->next;
    }
    /* cut is now the card 1/2 way through the deck */
    card *riffle=cut->next;
    cut->next = 0; /* deck and riffle now head separate lists */
    /* Shuffle the deck by randomly pulling a card from the head of "deck" or "riffle"
       and make it the new head of "retdeck" */
    card *retdeck=0;
    for(;deck || riffle;) { /* just like a while loop */
        card *temp;
        if(deck && (!riffle || drand48()<0.5)) {
            /* next card comes from the top of 'deck' */
            temp=deck;
            deck=deck->next;
        } else {
            /* next card comes from the top of 'riffle' */
            temp=riffle;
            riffle=riffle->next;
        }
        /* put the card at the top of the "retdeck" */
        temp->next=retdeck;
        retdeck=temp;
    }
    return retdeck;
}