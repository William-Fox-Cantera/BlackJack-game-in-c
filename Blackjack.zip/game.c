/* Contains main() and any desired helper functions to play the game as described in the instructions. Must not _define_ any of the
 * card-related helper functions but must use thm at least as frequently as indicated below (hit means either player or dealer hit):
 * make_deck:1; shuffle:1; deal: 3+1/hit; append: 1+1/hit; total: 2+1/hit; destroy_deck: 1
 */
#include "card.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

card *addToDeck(card *deck, card *headDeck);

int main(void) {
        //HEAD CARD
        card *firstCard = make_deck();
//--------------------------------------------------------------------------------------------------

        //SHUFFLING
        card *deck = shuffle(firstCard);

        //PLAYER AND COMPUTERS DECK
        card *playerDeck = NULL;
        card *computerDeck = NULL;

        //BLACKJACK VALUES
        int computerScore = 0;
        int playerScore = 0;

        //STARTING MESSAGES
        int msgOne = 1;
        int msgTwo = 1;
        int quit = 1;

        //CHOICE FOR PLAYER
        char playersChoice[] = "test";

        //PLAYER LOOP
        while(playerScore < 21) {
                if(msgOne) {
                        msgOne = 0;
                        printf("Welcome to BlackJack, will you play(p) or quit(q)?\n");
                        scanf("%s", playersChoice);
                }
                if(msgTwo && !strcmp(playersChoice, "p")) {
                        msgTwo = 0;

                        //DEAL FIRST TWO CARDS TO PLAYER, ONE TO DEALER
                        playerDeck = addToDeck(playerDeck, deck);
                        playerDeck = addToDeck(playerDeck, deck);
                        computerDeck = addToDeck(computerDeck, deck);
                        computerScore += computerDeck->rank;

                        printf("Your starting cards are:\n%d%c\nand\n%d%c    \nHit(h) or Stand(s)?\n", playerDeck->rank, playerDeck->suit, playerDeck->next->rank, playerDeck->next->suit);
                        scanf(" %s", playersChoice);
                }
                if(!strcmp(playersChoice, "h") || !strcmp(playersChoice, "H") || !strcmp(playersChoice, "hit") && (!msgOne && !msgTwo)) {
                        playerDeck = addToDeck(playerDeck, deck);
                        show(playerDeck);
                        
                        if(playerDeck->rank >= 11 && playerDeck->rank <= 13) {
                                playerScore += 10;
                        }
                        else {
                                playerScore += playerDeck->rank;
                        }

                        printf("Hit(h) or Stand(s)\n");
                        scanf(" %s", playersChoice);
                }
                if(!strcmp(playersChoice, "s") || !strcmp(playersChoice, "S") || !strcmp(playersChoice, "stand")) {
                        break;
                }
                if(!strcmp(playersChoice, "q")) {
                        quit = 0;
                        break;
                }
        }

        //If the player decided to quit by pressing q, this exits the game without an error
        if(quit) {

                //COMPUTER LOOP
                while(computerScore <= 17) {
                        computerDeck = addToDeck(computerDeck, deck);

                        if(computerDeck->rank >= 11 && computerDeck->rank <= 13) {
                                computerScore += 10;
                        }
                        else {
                                computerScore += computerDeck->rank;
                        }
                }


                //FINAL SCORES
                int playerTotal = total(playerDeck);
                int computerTotal = total(computerDeck);


                //WIN AND LOSS CONDITIONS
                if(playerTotal > 21) {
                        printf("Your cards(%d) exceed 21 you lose. The dealer has %d\n", playerTotal, computerTotal);
                }
                else if(computerTotal > 21) {
                        printf("The dealers total (%d) exceeds 21, your card total is: (%d) you win.\n", computerTotal, playerTotal);
                }
                else if(playerTotal <= 21 && computerTotal <= 21) {
                        if(playerTotal > computerTotal) {
                                printf("Your deck value (%d) is greater than the dealers deck value (%d)\n", playerTotal, computerTotal);
                        }
                        else if (playerTotal == computerTotal) {
                                printf("You and the dealer have the same deck values: (%d) You Lose.\n", computerTotal);
                        }
                        else {
                                printf("The dealers deck: (%d) is of higher value than yours: (%d), you lose.\n", computerTotal, playerTotal);
                        }
                }
                        destroy_deck(playerDeck);
                        destroy_deck(computerDeck);
                        destroy_deck(deck);
                }
                
//--------------------------------------------------------------------------------------------------
//TESTING
/*
 * Prints out deck
        while(deck != NULL) {
                printf("%d%c\n", deck->rank, deck->suit);
                deck = deck->next;
        }
*/
        //END OF MAIN
        return 0;

}
//---------------------------------------------------------------------------------------------------
//HELPER METHODS FOR PLAYING THE GAME

//Function for adding a card to the player/computer deck
card *addToDeck(card *deck, card *headDeck) {
        card *newCard = deal(headDeck);
        newCard->next = deck;
        deck = newCard;
        return deck;
}


